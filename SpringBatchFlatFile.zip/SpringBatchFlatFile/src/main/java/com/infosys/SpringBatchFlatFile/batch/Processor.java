package com.infosys.SpringBatchFlatFile.batch;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;
import com.infosys.SpringBatchFlatFile.model.Employee;

@Component
public class Processor implements ItemProcessor<Employee, Employee> {
	
	private static final Logger log = LoggerFactory.getLogger(Processor.class);
	
	private static final Map<String, String> DEPT_NAMES= new HashMap<>();
	
	public Processor() {
		log.info("...........INSIDE PROCESS CONSTRUCTOR.............");
		DEPT_NAMES.put("101", "Technology");
		DEPT_NAMES.put("102", "Accounts");
		DEPT_NAMES.put("103", "Operations");	
	}
	
	@Override
	public Employee process(Employee employee) throws Exception {	
		 String deptCode = employee.getDept();
	     String dept = DEPT_NAMES.get(deptCode);
	     employee.setDept(dept);
		/*log.info(String.format("Converted [%s],[%s]",deptCode,dept));*/
	     log.info("Employee DATA:" + employee.toString());
		return employee;
		
	}

}
