package com.infosys.SpringBatchFlatFile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBatchFlatFileApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchFlatFileApplication.class, args);
	}

}
