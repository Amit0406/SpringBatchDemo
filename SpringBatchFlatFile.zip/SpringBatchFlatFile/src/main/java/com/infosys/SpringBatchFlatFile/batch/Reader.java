package com.infosys.SpringBatchFlatFile.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.infosys.SpringBatchFlatFile.model.Employee;

@Component
public class Reader implements ItemReader<Employee>{
	
	private static final Logger log = LoggerFactory.getLogger(Reader.class);

	@Bean
	public FlatFileItemReader<Employee> itemReader(){
		log.info("...........INSIDE READER METHOD.............");
		FlatFileItemReader<Employee> flatFileItemReader= new FlatFileItemReader<>();
		flatFileItemReader.setResource(new FileSystemResource("src/main/resources/empdata.txt"));
		flatFileItemReader.setName("Flat-File-Reader");
		flatFileItemReader.setLinesToSkip(1);
		flatFileItemReader.setLineMapper(lineMapper());
		return flatFileItemReader;
	}
	
	
	public LineMapper<Employee> lineMapper() {
		DefaultLineMapper<Employee> lineMapper= new DefaultLineMapper<>();
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setStrict(false);
		lineTokenizer.setDelimiter(",");
		lineTokenizer.setNames(new String[] {"id", "name","dept","salary"});
		BeanWrapperFieldSetMapper<Employee> fieldSetMapper=new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(Employee.class);
		lineMapper.setLineTokenizer(lineTokenizer);
		lineMapper.setFieldSetMapper(fieldSetMapper);
		return lineMapper;
	}

	@Override
	public Employee read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		// TODO Auto-generated method stub
		return null;
	}

}
