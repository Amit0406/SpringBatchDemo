package com.infosys.SpringBatchFlatFile.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.infosys.SpringBatchFlatFile.model.Employee;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {
	
	private static final Logger log = LoggerFactory.getLogger(SpringBatchConfig.class);

	@Bean
	public Job job(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory,
			ItemReader<Employee> itemReader, ItemProcessor<Employee, Employee> itemProcessor,
			ItemWriter<Employee> itemWriter) {
		log.info("...........JOB STARTED.............");
		Step step = stepBuilderFactory.get("Flat-file Load-Step").<Employee, Employee>chunk(200).reader(itemReader)
				.processor(itemProcessor).writer(itemWriter).build();

		return jobBuilderFactory.get("Flat-Job").incrementer(new RunIdIncrementer()).start(step).build();

	}

}
