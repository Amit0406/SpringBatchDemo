package com.infosys.SpringBatchFlatFile.batch;

import java.util.List;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import com.infosys.SpringBatchFlatFile.model.Employee;

@Component
public class DBWriter implements ItemWriter<Employee> {

	private static final Logger log = LoggerFactory.getLogger(DBWriter.class);

	@Autowired
	DataSource dataSource;

	@Bean
	public JdbcBatchItemWriter<Employee> itemWriter() {
		log.info(".........INSIDE ITEM WRITTER...........");
		JdbcBatchItemWriter<Employee> empWriter = new JdbcBatchItemWriter<Employee>();
		empWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Employee>());
		empWriter.setSql("INSERT INTO Employee (id, name, dept, salary) VALUES (:id, :name, :dept, :salary)");
		empWriter.setDataSource(dataSource);
		return empWriter;
	}

	@Override
	public void write(List<? extends Employee> items) throws Exception {
		// TODO Auto-generated method stub

	}
}