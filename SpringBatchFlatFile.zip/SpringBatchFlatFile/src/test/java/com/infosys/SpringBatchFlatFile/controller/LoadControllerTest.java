package com.infosys.SpringBatchFlatFile.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.batch.test.context.SpringBatchTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

@RunWith(MockitoJUnitRunner.class)
@SpringBatchTest
public class LoadControllerTest {

	@InjectMocks
	private LoadController loadController;

	@Mock
	private JobLauncher jobLauncher;
	 
    @InjectMocks
    private JobExecution jobExecution;
	 
	
	@Test
	public void loadTest() throws Exception {
		ReflectionTestUtils.setField(jobExecution, "status", BatchStatus.COMPLETED);
		Mockito.when(jobLauncher.run(Mockito.any(), Mockito.any())).thenReturn(jobExecution);
		loadController.load();
		Assert.assertEquals(jobExecution.getStatus(),BatchStatus.COMPLETED);     
	}
	
}

