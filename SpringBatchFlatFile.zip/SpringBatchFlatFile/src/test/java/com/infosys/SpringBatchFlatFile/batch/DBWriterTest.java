package com.infosys.SpringBatchFlatFile.batch;

import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;

import com.infosys.SpringBatchFlatFile.model.Employee;

@RunWith(MockitoJUnitRunner.class)
public class DBWriterTest {
	
	@Mock
	Employee employee;
	
	@Mock
	DataSource dataSource;
	
	@InjectMocks
	DBWriter dbwriter;
	
	@Mock
	ItemWriter<Employee> itemwriter;
	
	
	@Test
	public void JdbcBatchItemWriterTest(){
		JdbcBatchItemWriter<Employee> empWriter = new JdbcBatchItemWriter<Employee>();
		empWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Employee>());
		empWriter.setSql("INSERT INTO Employee (id, name, dept, salary) VALUES (1, 'sonali', 'acc', '12233333')");
		empWriter.setDataSource(dataSource);
		dbwriter.itemWriter();
		 Assert.assertNotNull(empWriter);
  	}
} 

