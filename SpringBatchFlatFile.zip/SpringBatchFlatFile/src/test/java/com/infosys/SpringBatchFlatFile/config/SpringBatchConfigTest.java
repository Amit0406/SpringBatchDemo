package com.infosys.SpringBatchFlatFile.config;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.test.context.SpringBatchTest;

import com.infosys.SpringBatchFlatFile.model.Employee;


//@RunWith(MockitoJUnitRunner.class)
//@SpringBatchTest
public class SpringBatchConfigTest {
	
	
	/*@Mock
    private StepBuilderFactory stepBuilderFactory;
	
	 @Mock
	 private StepBuilder stepBuilder;

    @Mock
    private SimpleStepBuilder<Employee, Employee> simpleStepBuilder;

    @Mock
    FlatFileItemWriter<Employee> myWriter;

    @Mock
    JdbcCursorItemReader<Employee> myReader;

    @InjectMocks
    private SpringBatchConfig springBatchConfig;;
	

    
    @Before
    public void setUp() {
        Mockito.when(stepBuilderFactory.get(toString())).thenReturn(stepBuilder);
        Mockito.when(stepBuilder.chunk(Mockito.any())).thenReturn(simpleStepBuilder);
        Mockito.when(simpleStepBuilder.reader(myReader)).thenReturn(simpleStepBuilder);
        Mockito.when(simpleStepBuilder.writer(myWriter)).thenReturn(simpleStepBuilder);
    }

	@Test
	public void jobTest() {
	
		  final Step step = (Step) springBatchConfig.job(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
		  Assert.assertNotNull(step);
		
	}*/

}
