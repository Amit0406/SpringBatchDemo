package com.infosys.SpringBatchFlatFile.batch;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.test.context.SpringBatchTest;
import org.springframework.stereotype.Component;
import com.infosys.SpringBatchFlatFile.model.Employee;




@RunWith(MockitoJUnitRunner.class)
@SpringBatchTest
public class ProcessorTest {
	
	@Mock
	Employee employee;
	
	@InjectMocks
	Processor processor;
	
	private static final Logger log = LoggerFactory.getLogger(Processor.class);
	
	private static final Map<String, String> DEPT_NAMES= new HashMap<>();
	
	public ProcessorTest() {
		log.info("...........INSIDE PROCESS CONSTRUCTOR.............");
		DEPT_NAMES.put("120", "Technology");
		DEPT_NAMES.put("102", "Accounts");
		DEPT_NAMES.put("103", "Operations");	
	}
	
	@Test
	public void processTest() throws Exception {
		 employee.setDept("120");
		 String deptCode = employee.getDept();
	     String dept = DEPT_NAMES.get(deptCode);
	     employee.setDept(dept);
	     processor.process(employee);
	     Assert.assertNotNull(employee);
		
		}

}
