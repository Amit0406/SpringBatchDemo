package com.infosys.SpringBatchFlatFile.batch;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.test.context.SpringBatchTest;
import org.springframework.core.io.FileSystemResource;
import com.infosys.SpringBatchFlatFile.model.Employee;

@RunWith(MockitoJUnitRunner.class)
@SpringBatchTest
public class ReaderTest{
	
	@InjectMocks
	Reader reader;

	@InjectMocks
	FlatFileItemReader<Employee> flatFileItemReader;
	
	@Mock
	LineMapper<Employee> lineMapper;
	
	
	@Test
	public void itemReaderTest() throws UnexpectedInputException, ParseException, Exception{
		flatFileItemReader.setResource(new FileSystemResource("src/main/resources/empdata.txt"));
		flatFileItemReader.setName("Flat-File-Reader");
		flatFileItemReader.setLinesToSkip(1);
	    reader.itemReader();
	    Assert.assertNotNull(flatFileItemReader);
	}

}
