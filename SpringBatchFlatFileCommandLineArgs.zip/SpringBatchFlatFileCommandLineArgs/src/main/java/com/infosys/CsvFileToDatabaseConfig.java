package com.infosys;

import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;

@EnableBatchProcessing
@Configuration
public class CsvFileToDatabaseConfig {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	public DataSource dataSource;

	Logger logger = LoggerFactory.getLogger(CsvFileToDatabaseConfig.class);

	// begin reader, writer, and processor
	
	  @Bean 
	  public Job job2() { 
	      return jobBuilderFactory
			.get("Job")
			.incrementer(new RunIdIncrementer())
			.start(step2())
			.build(); 
	 }
	  
	  
	  @Bean 
	  ItemProcessor<Book, Book> csvAnimeProcessor() { 
		  return new BookProcessor(); 
		  }
	  
	  @Bean public Step step2() { 
		return stepBuilderFactory
				.get("step").<Book,Book>chunk(200)
				.reader(reader(null))
	            .processor(csvAnimeProcessor())
	            .writer(writer())
	            .build(); 
		}
	  
	  
	  @Bean
	  @StepScope 
	  public FlatFileItemReader<Book> reader(@Value("#{jobParameters['file']}") String file){
	  FlatFileItemReader<Book> flatFileItemReader = new FlatFileItemReader<Book>();
	  flatFileItemReader.setResource(new ClassPathResource(file)); 
	  flatFileItemReader.setLinesToSkip(1);
	  flatFileItemReader.setLineMapper(lineMapper());
	  return flatFileItemReader;
	}
	
	
	private LineMapper<Book> lineMapper() {
		DefaultLineMapper<Book> lineMapper= new DefaultLineMapper<>();
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setStrict(false);
		lineTokenizer.setDelimiter(",");
		lineTokenizer.setNames(new String[] {"id", "title", "description"});
		BeanWrapperFieldSetMapper<Book> fieldSetMapper=new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(Book.class);
		lineMapper.setLineTokenizer(lineTokenizer);
		lineMapper.setFieldSetMapper(fieldSetMapper);
		return lineMapper;
	}
	  
	  
	  @Bean 
	  public ItemWriter<Book> writer() { 
	  JdbcBatchItemWriter<Book>  writer = new JdbcBatchItemWriter<Book>();
	  writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Book>()); 
	  writer.setSql("INSERT INTO Book (id, title, description) VALUES (:id, :title, :description)"); 
	  writer.setDataSource(dataSource); 
	  return writer; 
	  } 
	  
}
