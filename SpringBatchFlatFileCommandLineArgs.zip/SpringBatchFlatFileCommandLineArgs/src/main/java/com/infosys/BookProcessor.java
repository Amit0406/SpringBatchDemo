package com.infosys;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

public class BookProcessor implements ItemProcessor<Book, Book> {
	
    private static final Logger log = LoggerFactory.getLogger(BookProcessor.class);
    
    @Override
    public Book process(final Book book) throws Exception {
    	
    	final String id = book.getId();
        final String title = book.getTitle();
        final String description = book.getDescription();

        final Book transformedBook = new Book(id, title, description);

        log.info("Book DATA:" + transformedBook.toString());

        return transformedBook;
    }

}
